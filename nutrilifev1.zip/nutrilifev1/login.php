<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap.css">
	 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://fonts.googleapis.com/css2?family=Mulish:wght@300&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</head>
<body>
	<!DOCTYPE html>
<html>
<head>
	<title>nutrilife</title>
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" media="all" />
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<!--	<div class="bgimage">
		<div class="menu">
			<div class="leftmenu">
				<h1>
					<a href="file:///C:/xampp/htdocs/nutrilife/index.html">NutriLife</a>
				</h1>
			</div>
			<div class="rightmenu">
				<ol>
					<li><a href="file:///C:/xampp/htdocs/nutrilife/index.html">home</a></li>
					<li>Services</li>
					<li>about us</li>
					<li><a href="http://localhost/nutrilife/login.php">login</a></li>
					<li><a href="http://localhost/nutrilife/login.php">signup</a></li>
					
				</ol>
			</div>
		</div>
		<div class="text">
			<h1><i>Stay Healthy</i></h1>
			<div class="maindiv">

				
			
	</div>
	<div class="hoho">
		
	</div>

-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#"><b>NutriLife</b></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Services</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Contact Us</a>
      </li>
      

    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-secondary my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>

		<div class="container">
			<div class="row">
				<div class="col-lg-6" style="margin-top: 15px">
					<h2>Login Form</h2>

					<form action="validation.php" method="post">
						<div class="form-group">
							<label> username </label>
							<input type="text" name="user" class="form-control">
							
						</div>
						<div class="form-group">
							<label> password </label>
							<input type="password" name="password" class="form-control">
							
						</div>

						<button  type="submit" class="btn btn-secondary"> login </button>
						
					</form>
				    </div>
				    <br>
				    <br>
				    <br>
				    <br>

					<div class="col-lg-6 " style="margin-top: 15px">
					<h2>Signup Form</h2>

					<form action="registration.php" method="post">
						<div class="form-group">
							<label> username </label>
							<input type="text" name="user" class="form-control">
							
						</div>
						<div class="form-group ">
							<label> password </label>
							<input type="password" name="password" class="form-control">
							
						</div>

						<button type="submit" class="btn btn-secondary"> signup </button>
						
					</form>
					
			</div>
				 
		</div>
</div>

</body>
</html>