<?php


session_start();

header('location:login.php');

$con = mysqli_connect('localhost','root');
if ($con) {
	echo "connection successful";
}else{
	echo "no connection";
}

mysqli_select_db($con, 'sessionpratical1');

$name = $_POST['user'];
$pass = $_POST['password'];


$q = " select * from signin where name = '$name' && password = '$pass' ";

$result = mysqli_query($con, $q);

$num = mysqli_num_rows($result);

if ($num==1) {
	$_SESSION['username'] = $name;
	header('location:file:///C:/xampp/htdocs/nutrilife/index1.html');
}else{
	header('location:login.php');

}


?>